#include <iostream>
using namespace std;
int main ()
{
	int num=10, a=0;
	
	for (int i=0; i<+num; i++)
	{
		a+=(i+1);
		cout<<"\t"<<a;
	}


return 0;
}


