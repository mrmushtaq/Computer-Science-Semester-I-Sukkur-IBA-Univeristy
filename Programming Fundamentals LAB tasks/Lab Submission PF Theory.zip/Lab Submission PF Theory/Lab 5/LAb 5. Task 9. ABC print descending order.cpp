#include <iostream>
using namespace std;
int main ()
{

	for (char i='Z'; i>='A'; i--)
	cout<<i<<"\t";

return 0;
}


