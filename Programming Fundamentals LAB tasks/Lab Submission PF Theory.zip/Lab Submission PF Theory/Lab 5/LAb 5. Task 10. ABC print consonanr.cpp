#include <iostream>
using namespace std;
int main ()
{

	for (char i='Z'; i>='A'; i--)
	{
		if(i!='A' && i!='E' && i!='I' &&i!='O' && i!='U')
		cout<<i<<"\t";
	}
	

return 0;
}


