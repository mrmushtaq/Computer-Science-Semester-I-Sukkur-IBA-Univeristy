#include <iostream>
using namespace std;
int main ()
{
		int num=10, a=0;
	int i=0;
	while ( i<=num)
	{
		a+=(i+1);
		cout<<"\t"<<a;
		i++;
	}



return 0;
}


