#include<iostream>
using namespace std;
int main ()
{
     int number;
     cout<<"\nEnter a number\n";
     cin>>number;	
  if(number%2==0)
     cout<<"\n"<<number<<" is even\n";
  else
     cout<<"\n"<<number<<" is odd\n";
     return 0;
}

