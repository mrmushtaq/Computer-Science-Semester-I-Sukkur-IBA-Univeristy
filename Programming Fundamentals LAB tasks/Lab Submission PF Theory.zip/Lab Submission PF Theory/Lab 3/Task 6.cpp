#include<iostream>
using namespace std;
int main()
{
	int number;
	cout<<"\nEnter a month number (1 to 12)\n";
	cin>>number;
	
	if(number==1)
	cout<<"\nThe first month is January";
	else if(number==2)
	cout<<"\nThe second month is February";
	else if(number==3)
	cout<<"\nThe third month is March";
	else if(number==4)
	cout<<"\nThe fourth month is April";
	else if(number==5)
	cout<<"\nThe fifth month is May";
	else if(number==6)
	cout<<"\nThe sixth month is June";
	else if(number==7)
	cout<<"\nThe seventh month is July";
	else if(number==8)
	cout<<"\nThe eighth month is August";
	else if(number==9)
	cout<<"\nThe ninth month is September";
	else if(number==10)
	cout<<"\nThe tenth month is October";
	else if(number==11)
	cout<<"\nThe Eleventh month is November";
	else if(number==12)
	cout<<"\nThe twelfth month is December";
	else
	cout<<"Invalid input";
	
	
return 0;
}

