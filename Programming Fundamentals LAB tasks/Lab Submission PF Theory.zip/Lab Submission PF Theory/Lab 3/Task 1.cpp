#include<iostream>
using namespace std;
int main ()
{
	int num1, num2;
	cout<<"Enter NO#1.\n";
	cin>>num1;
	cout<<"Enter NO#2.\n";
	cin>>num2;

	if(num1==num2)
		cout<<"\n"<<num1<<" and "<<num2<<" are Equal" <<endl;
	else
		cout<<"\n"<<num1<<" and "<<num2<<" are not Equal" <<endl;
return 0;
}

