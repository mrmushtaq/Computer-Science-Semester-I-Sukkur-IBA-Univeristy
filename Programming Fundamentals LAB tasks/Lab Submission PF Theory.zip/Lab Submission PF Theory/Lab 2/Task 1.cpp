#include <iostream>
using namespace std;
int main ()
{
	int a, b;
	float c;
	
  	cout<<"Enter an integer number"<<endl;
  	cin>>a;
  
  	cout<<"Enter another integer number"<<endl;
  	cin>>b;
  
  	cout<<"Enter a decimal number"<<endl;
  	cin>>c;
  
cout<<a<<" and "<<b<<" are integers and "<<c<<" is a decimal number";
  
 	return 0;
 }

