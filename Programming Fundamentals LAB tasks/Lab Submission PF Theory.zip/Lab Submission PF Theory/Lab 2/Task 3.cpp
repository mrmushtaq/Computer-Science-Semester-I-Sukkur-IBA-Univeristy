#include <iostream>

using namespace std;
int main ()
{
  	double amount;
	cout<<"Enter your Total amount in rupees"<<endl;
	cin>>amount;
	
	cout<<"You have to pay "<<2.5/100*amount<<" rupees as Zakat"<<endl;

  return 0;
 }

