#include <iostream>
using namespace std;
int main()
 {
  	float a,b,x;
          cout<<"The given equation is"<<"  x = 2(a+b)-2ab\n";
          cout<<"Solve for x\n\n";
          cout<<"Enter value of a. "<<endl;
    cin>>a;
            cout<<"Enter value of b. "<<endl;
    cin>>b;
                      x = (2*(a+b)-2*a*b);
                cout<<"The value of x will be "<<x<<endl;

    return 0;
}

